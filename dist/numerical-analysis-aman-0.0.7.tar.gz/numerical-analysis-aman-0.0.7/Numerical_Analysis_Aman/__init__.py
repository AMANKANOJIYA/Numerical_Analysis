# Version Of Module
from .Numerical_Analysis import Numerical_Analysis,Numerical_Integration,Numerical_Interpolation,Numerical_Algebra
__version__="0.0.7"