# Version Of Module
from .Numerical_Analysis import Numerical_Analysis,Numerical_Integration,Numerical_Interpolation
__version__="0.0.2"