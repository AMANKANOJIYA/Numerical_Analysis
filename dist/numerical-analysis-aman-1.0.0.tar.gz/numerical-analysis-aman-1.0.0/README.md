# Numerical Analysis

This Module is Numerical analysis, area of mathematics and computer science that creates, analyzes, and implements algorithms for obtaining numerical solutions to problems involving continuous variables. Such problems arise throughout the natural sciences, social sciences, engineering, medicine, and business.

## How It Works

## How to Install

Pip install this module from your console
`pip install _________`

## license

This repository is licensed under the MIT license.
See LICENSE for details.
